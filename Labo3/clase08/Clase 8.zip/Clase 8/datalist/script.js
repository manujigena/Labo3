$(document).ready(function(){

    $("input[name=color]").change(function() {
		alert($("input[name=color]").val());
		});

});