<?php
//si hay post saco el valor
if($_POST)
	{
	echo "El color seleccionado es: ".$_POST['color'];
	}
?>