<?php
echo $_REQUEST['first_name'];
?> 