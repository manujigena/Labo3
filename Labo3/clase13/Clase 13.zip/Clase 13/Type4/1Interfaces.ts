
function enviarMision(xmen:{ nombre:string } ){
    console.log("Enviando a: " + xmen.nombre);
}

let wolverine = {
    nombreXmen:"James",
    poder: "Regeneración"
};

enviarMision(wolverine);








